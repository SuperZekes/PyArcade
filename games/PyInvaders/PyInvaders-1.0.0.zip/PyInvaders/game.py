import tkinter as tk
from tkinter import messagebox
import threading
from playsound import playsound

class HomeScreen:
    def __init__(self, root):
        self.root = root
        self.root.title("PyInvaders")
        
        # Create a label for the title
        self.title_label = tk.Label(root, text="Welcome to PyInvaders", font=("Arial", 24))
        self.title_label.pack(pady=20)
        
        # Create a start button
        self.start_button = tk.Button(root, text="Start Game", command=self.start_game)
        self.start_button.pack(pady=10)

    def start_game(self):
        # Destroy the home screen elements
        self.title_label.destroy()
        self.start_button.destroy()
        
        # Start the game
        game = PyInvaders(self.root)

class PyInvaders:
    def __init__(self, root):
        self.root = root
        self.root.title("PyInvaders")

        self.canvas = tk.Canvas(root, width=600, height=400, bg='black')
        self.canvas.pack()

        self.ship = self.canvas.create_rectangle(270, 350, 330, 370, fill='blue')

        self.bullets = []
        self.invaders = []

        self.invader_image = tk.PhotoImage(file='assets/invader.png')
        self.create_invaders()

        self.root.bind('<Left>', self.move_left)
        self.root.bind('<Right>', self.move_right)
        self.root.bind('<space>', self.shoot)

        self.invader_direction = 1
        self.game_over = False
        self.you_win = False

        self.update_game()

    def create_invaders(self):
        for i in range(5):
            for j in range(3):
                invader = self.canvas.create_image(70 + i * 100, 65 + j * 50, image=self.invader_image)
                self.invaders.append(invader)

    def move_left(self, event):
        if self.canvas.coords(self.ship)[0] > 0:
            self.canvas.move(self.ship, -10, 0)

    def move_right(self, event):
        if self.canvas.coords(self.ship)[2] < 600:
            self.canvas.move(self.ship, 10, 0)

    def shoot(self, event):
        bullet = self.canvas.create_rectangle(self.canvas.coords(self.ship)[0] + 27, 340, self.canvas.coords(self.ship)[0] + 33, 350, fill='yellow')
        self.bullets.append(bullet)
        threading.Thread(target=playsound, args=('assets/shoot.mp3',), daemon=True).start()

    def update_game(self):
        if not self.game_over and not self.you_win:
            self.move_bullets()
            self.move_invaders()
            self.check_collisions()
            self.check_game_over()
            self.check_win()
            self.root.after(50, self.update_game)

    def move_bullets(self):
        for bullet in self.bullets:
            self.canvas.move(bullet, 0, -10)
            if self.canvas.coords(bullet)[1] < 0:
                self.canvas.delete(bullet)
                self.bullets.remove(bullet)

    def move_invaders(self):
        move_down = False
        for invader in self.invaders:
            x0, y0 = self.canvas.coords(invader)
            if x0 >= 600 and self.invader_direction > 0:
                move_down = True
            elif x0 <= 0 and self.invader_direction < 0:
                move_down = True
        
        for invader in self.invaders:
            if move_down:
                self.canvas.move(invader, 0, 20)
            else:
                self.canvas.move(invader, self.invader_direction * 5, 0)

        if move_down:
            self.invader_direction *= -1

    def check_collisions(self):
        for bullet in self.bullets:
            for invader in self.invaders:
                if self.check_overlap(self.canvas.coords(bullet), self.canvas.coords(invader)):
                    self.canvas.delete(bullet)
                    self.bullets.remove(bullet)
                    self.canvas.delete(invader)
                    self.invaders.remove(invader)
                    threading.Thread(target=playsound, args=('assets/invader_hit.mp3',), daemon=True).start()
                    break

    def check_overlap(self, bullet_coords, invader_coords):
        bullet_x0, bullet_y0, bullet_x1, bullet_y1 = bullet_coords
        invader_x, invader_y = invader_coords
        invader_width = self.invader_image.width()
        invader_height = self.invader_image.height()
        return (bullet_x1 >= invader_x - invader_width // 2 and bullet_x0 <= invader_x + invader_width // 2 and
                bullet_y1 >= invader_y - invader_height // 2 and bullet_y0 <= invader_y + invader_height // 2)

    def check_game_over(self):
        for invader in self.invaders:
            if self.canvas.coords(invader)[1] >= 400:
                self.game_over = True
                self.canvas.create_text(300, 200, text="GAME OVER", fill="white", font=("Arial", 24))
                break

    def check_win(self):
        if not self.invaders:
            self.you_win = True
            self.canvas.create_text(300, 200, text="YOU WIN!", fill="white", font=("Arial", 24))

if __name__ == "__main__":
    root = tk.Tk()
    home_screen = HomeScreen(root)
    root.mainloop()
